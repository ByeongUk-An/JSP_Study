
Create table guestboard2 (
	name varchar2 (100),
	email varchar2(100), 
	inputdate varchar2 (100) primary key , 
	subject varchar2(100), 
	content varchar2 (2000) 
	); 